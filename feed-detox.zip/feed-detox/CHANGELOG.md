# Changelog

## [0.1.0] — initial scaffold
- Manifest V3 skeleton
- Per-site content scripts (stubs)
- Popup with three toggles
- chrome.storage.sync wiring
- Working starter selector for YouTube Shorts sidebar tab
