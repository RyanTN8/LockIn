const DEFAULTS = {
  youtube: { enabled: true },
  instagram: { enabled: true },
  tiktok: { enabled: true, mode: "redirect" },
};

const SITES = ["youtube", "instagram", "tiktok"];

async function load() {
  const { settings } = await chrome.storage.sync.get("settings");
  const current = settings || DEFAULTS;
  SITES.forEach((site) => {
    document.getElementById(site).checked = current[site]?.enabled ?? true;
  });
}

async function save() {
  const { settings } = await chrome.storage.sync.get("settings");
  const current = settings || DEFAULTS;
  SITES.forEach((site) => {
    current[site] = { ...current[site], enabled: document.getElementById(site).checked };
  });
  await chrome.storage.sync.set({ settings: current });
}

SITES.forEach((site) => {
  document.getElementById(site).addEventListener("change", save);
});

load();
