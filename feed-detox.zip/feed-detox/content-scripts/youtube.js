// YouTube content script.
// Hides Shorts across the YouTube web app.
//
// Selectors live in /selectors.md — do not invent new ones here.
// Add them to selectors.md first, then reference them in SELECTORS below.

const SELECTORS = [
  // Starter selector — hides the Shorts link in the sidebar.
  // Phase 2 will expand this list. See TASKS.md.
  'a[title="Shorts"]',
];

async function applyHiding() {
  const settings = await FeedDetox.getSettings();
  if (!settings.youtube?.enabled) {
    SELECTORS.forEach((s) => FeedDetox.unhide(s));
    return;
  }
  SELECTORS.forEach((s) => FeedDetox.hide(s));
}

FeedDetox.observe(applyHiding);
FeedDetox.onSettingsChanged(applyHiding);
