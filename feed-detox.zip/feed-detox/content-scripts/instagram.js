// Instagram content script.
// Hides Reels in the nav, on profiles, and inline in the feed.
//
// Selectors live in /selectors.md — do not invent new ones here.
// To be filled out in Phase 3. See TASKS.md.

const SELECTORS = [
  // TODO: add Instagram selectors from selectors.md once captured.
];

async function applyHiding() {
  const settings = await FeedDetox.getSettings();
  if (!settings.instagram?.enabled) {
    SELECTORS.forEach((s) => FeedDetox.unhide(s));
    return;
  }
  SELECTORS.forEach((s) => FeedDetox.hide(s));
}

FeedDetox.observe(applyHiding);
FeedDetox.onSettingsChanged(applyHiding);
