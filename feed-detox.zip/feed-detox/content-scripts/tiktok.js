// TikTok content script.
// Redirects For You to Following, and/or hides the For You tab.
//
// Selectors live in /selectors.md — do not invent new ones here.
// To be filled out in Phase 4. See TASKS.md.

async function applyHiding() {
  const settings = await FeedDetox.getSettings();
  if (!settings.tiktok?.enabled) return;

  // TODO Phase 4: implement redirect from root / foryou → /following
  // TODO Phase 4: implement For You tab hiding when mode === "hide"
}

FeedDetox.observe(applyHiding);
FeedDetox.onSettingsChanged(applyHiding);
