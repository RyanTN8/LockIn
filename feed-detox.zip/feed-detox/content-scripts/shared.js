// Shared utilities used by every site's content script.
// Loaded before the per-site script via manifest.json.

const FeedDetox = {
  // Hide every element matching a selector. Idempotent.
  hide(selector) {
    document.querySelectorAll(selector).forEach((el) => {
      el.dataset.feedDetoxHidden = "true";
      el.style.setProperty("display", "none", "important");
    });
  },

  // Un-hide elements previously hidden by this extension only.
  unhide(selector) {
    document.querySelectorAll(`${selector}[data-feed-detox-hidden]`).forEach((el) => {
      el.style.removeProperty("display");
      delete el.dataset.feedDetoxHidden;
    });
  },

  // Run `callback` now and again whenever the DOM changes.
  // Use this to catch lazy-loaded content as the user scrolls.
  observe(callback) {
    callback();
    const observer = new MutationObserver(() => callback());
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
    return observer;
  },

  // Read settings from chrome.storage.sync.
  async getSettings() {
    const { settings } = await chrome.storage.sync.get("settings");
    return settings || {
      youtube: { enabled: true },
      instagram: { enabled: true },
      tiktok: { enabled: true, mode: "redirect" },
    };
  },

  // Subscribe to settings changes. Callback receives the new settings.
  onSettingsChanged(callback) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync" && changes.settings) {
        callback(changes.settings.newValue);
      }
    });
  },
};
