# Icons needed

Chrome requires three PNG icons. Drop them in this folder before
loading the extension, or the toolbar icon will be missing.

Required files:
- icon-16.png  (16x16)
- icon-48.png  (48x48)
- icon-128.png (128x128)

Quickest path for v1: make a flat colored square with a letter "F"
in Figma, Excalidraw, or even Preview. Save at the three sizes.

Until you add real icons, you can comment out the "icons" and
"default_icon" blocks in manifest.json and the extension will still
load (with a generic puzzle-piece icon).
