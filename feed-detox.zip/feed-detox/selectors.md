# DOM Selectors

This file is the source of truth for which elements the extension hides.
Claude should never invent selectors. If you need one that isn't here,
capture it from the live site and add it below.

## How to capture a selector
1. Open the site in Chrome
2. Right-click the element you want to hide → Inspect
3. In DevTools, right-click the element in the Elements panel
4. Copy → Copy selector (or copy a more stable one by hand)
5. Test it: in the DevTools Console, run
   `document.querySelectorAll('YOUR_SELECTOR').length`
6. Add it below with the date captured

Prefer selectors based on:
- aria-label (stable, accessible)
- href patterns (e.g. `a[href^="/shorts/"]`)
- title attributes
- semantic tag names (ytd-rich-section-renderer)
Avoid:
- Auto-generated class names like `_aacl _aaco` — they change often
- Deep nth-child chains — they break on layout changes

---

## YouTube selectors

_Captured: TODO — fill in before starting Phase 2_

### Shorts shelf on homepage
- Likely candidate: `ytd-rich-section-renderer:has(a[title="Shorts"])`
- Fallback: `ytd-rich-shelf-renderer[is-shorts]`

### Shorts tab in left sidebar
- Likely candidate: `a[title="Shorts"]`
- Mini-sidebar variant: TODO

### Shorts in search results
- Likely candidate: `ytd-reel-shelf-renderer`
- Individual: `ytd-video-renderer:has(a[href^="/shorts/"])`

### Shorts in subscription feed
- TODO

---

## Instagram selectors

_Captured: TODO — fill in before starting Phase 3_

### Reels tab in left navigation
- TODO

### Reels grid tab on profile
- TODO

### Inline Reels in main feed
- TODO

---

## TikTok selectors

_Captured: TODO — fill in before starting Phase 4_

### For You tab in top nav
- TODO

### URL pattern for redirect
- From: `https://www.tiktok.com/` or `https://www.tiktok.com/foryou`
- To: `https://www.tiktok.com/following`
